﻿Public Class SignInForm
    Public DBUserName, DBPassword As String
    Public DBLocation As Integer

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim LastRow, UserID, LoopCount, RowCount, Level, DBLevel As Integer
        Dim UserName, Password As String
        Dim UserFound As Boolean
        Dim StartTime, EndTime As DateTime
        Dim MyDate As DateTime

        MainForm.TBL_UserTableAdapter.Fill(MainForm.DBDS.TBL_User)

        UserName = txtUser.Text
        Password = txtPassword.Text
        RowCount = MainForm.DBDS.TBL_User.Rows.Count - 1
        LoopCount = 0
        UserFound = False
        Do While (LoopCount <= RowCount) And (UserFound = False)
            DBUserName = MainForm.DBDS.Tables("TBL User").Rows(LoopCount)(1).ToString()
            If UserName = DBUserName Then
                UserFound = True
            Else
                LoopCount = LoopCount + 1
            End If
        Loop
        DBLocation = LoopCount
        If Not UserFound Then
            MessageBox.Show("User not found.")
        Else
            DBPassword = MainForm.DBDS.Tables("TBL User").Rows(LoopCount)(2).ToString()
            If Password <> DBPassword Then
                MessageBox.Show("Incorrect Password.")
            Else
                DBLevel = MainForm.DBDS.Tables("TBL User").Rows(LoopCount)(3).ToString()
                Level = DBLevel
                StartTime = TimeOfDay
                MyDate = Today
                UserID = MainForm.DBDS.Tables("TBL User").Rows(LoopCount)(0)
                Select Case Level
                    Case 1
                        'MessageBox.Show("Admin")
                        SystemAdministrator.ShowDialog()
                    Case 2
                        'MessageBox.Show("Moderator")
                        Teacher.ShowDialog()
                    Case 3
                        'MessageBox.Show("User")
                        Student.ShowDialog()
                End Select
                EndTime = TimeOfDay

                MainForm.DBDS.TBL_Session.Rows.Add()
                LastRow = MainForm.DBDS.TBL_Session.Rows.Count - 1
                MainForm.DBDS.Tables("TBL SESSION").Rows(LastRow)(2) = UserID
                MainForm.DBDS.Tables("TBL SESSION").Rows(LastRow)(3) = MyDate
                MainForm.DBDS.Tables("TBL SESSION").Rows(LastRow)(4) = StartTime
                MainForm.DBDS.Tables("TBL SESSION").Rows(LastRow)(5) = EndTime
                MainForm.TBL_SessionTableAdapter.Update(MainForm.DBDS.TBL_Session)
                MainForm.TBL_SessionTableAdapter.Fill(MainForm.DBDS.TBL_Session)
            End If
        End If
        txtUser.Text = ""
        txtPassword.Text = ""
    End Sub
End Class