﻿Public Class Student

End Class