﻿Public Class MainForm
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DBDS.TBL_User' table. You can move, or remove it, as needed.
        Me.TBL_UserTableAdapter.Fill(Me.DBDS.TBL_User)
        'TODO: This line of code loads data into the 'DBDS.TBL_Session' table. You can move, or remove it, as needed.
        Me.TBL_SessionTableAdapter.Fill(Me.DBDS.TBL_Session)
        'TODO: This line of code loads data into the 'DBDS.TBL_Level' table. You can move, or remove it, as needed.
        Me.TBL_LevelTableAdapter.Fill(Me.DBDS.TBL_Level)
        'TODO: This line of code loads data into the 'DBDS.Rewards' table. You can move, or remove it, as needed.
        Me.RewardsTableAdapter.Fill(Me.DBDS.Rewards)


    End Sub

    Private Sub btnSignIn_Click(sender As Object, e As EventArgs) Handles btnSignIn.Click
        SignInForm.ShowDialog()
    End Sub
End Class

