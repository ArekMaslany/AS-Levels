﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DBDS = New School_Rewards_System.DBDS()
        Me.RewardsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.RewardsTableAdapter = New School_Rewards_System.DBDSTableAdapters.RewardsTableAdapter()
        Me.TBLLevelBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TBL_LevelTableAdapter = New School_Rewards_System.DBDSTableAdapters.TBL_LevelTableAdapter()
        Me.TBLSessionBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TBL_SessionTableAdapter = New School_Rewards_System.DBDSTableAdapters.TBL_SessionTableAdapter()
        Me.TBLUserBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TBL_UserTableAdapter = New School_Rewards_System.DBDSTableAdapters.TBL_UserTableAdapter()
        Me.btnSignIn = New System.Windows.Forms.Button()
        CType(Me.DBDS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RewardsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TBLLevelBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TBLSessionBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TBLUserBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DBDS
        '
        Me.DBDS.DataSetName = "DBDS"
        Me.DBDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'RewardsBindingSource
        '
        Me.RewardsBindingSource.DataMember = "Rewards"
        Me.RewardsBindingSource.DataSource = Me.DBDS
        '
        'RewardsTableAdapter
        '
        Me.RewardsTableAdapter.ClearBeforeFill = True
        '
        'TBLLevelBindingSource
        '
        Me.TBLLevelBindingSource.DataMember = "TBL Level"
        Me.TBLLevelBindingSource.DataSource = Me.DBDS
        '
        'TBL_LevelTableAdapter
        '
        Me.TBL_LevelTableAdapter.ClearBeforeFill = True
        '
        'TBLSessionBindingSource
        '
        Me.TBLSessionBindingSource.DataMember = "TBL Session"
        Me.TBLSessionBindingSource.DataSource = Me.DBDS
        '
        'TBL_SessionTableAdapter
        '
        Me.TBL_SessionTableAdapter.ClearBeforeFill = True
        '
        'TBLUserBindingSource
        '
        Me.TBLUserBindingSource.DataMember = "TBL User"
        Me.TBLUserBindingSource.DataSource = Me.DBDS
        '
        'TBL_UserTableAdapter
        '
        Me.TBL_UserTableAdapter.ClearBeforeFill = True
        '
        'btnSignIn
        '
        Me.btnSignIn.Location = New System.Drawing.Point(197, 21)
        Me.btnSignIn.Name = "btnSignIn"
        Me.btnSignIn.Size = New System.Drawing.Size(75, 23)
        Me.btnSignIn.TabIndex = 0
        Me.btnSignIn.Text = "Sign in."
        Me.btnSignIn.UseVisualStyleBackColor = True
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.btnSignIn)
        Me.Name = "MainForm"
        Me.Text = "Main Form"
        CType(Me.DBDS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RewardsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TBLLevelBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TBLSessionBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TBLUserBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DBDS As DBDS
    Friend WithEvents RewardsBindingSource As BindingSource
    Friend WithEvents RewardsTableAdapter As DBDSTableAdapters.RewardsTableAdapter
    Friend WithEvents TBLLevelBindingSource As BindingSource
    Friend WithEvents TBL_LevelTableAdapter As DBDSTableAdapters.TBL_LevelTableAdapter
    Friend WithEvents TBLSessionBindingSource As BindingSource
    Friend WithEvents TBL_SessionTableAdapter As DBDSTableAdapters.TBL_SessionTableAdapter
    Friend WithEvents TBLUserBindingSource As BindingSource
    Friend WithEvents TBL_UserTableAdapter As DBDSTableAdapters.TBL_UserTableAdapter
    Friend WithEvents btnSignIn As Button
End Class
