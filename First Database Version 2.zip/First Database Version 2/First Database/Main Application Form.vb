﻿Public Class Main_Application_Form
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Application.Exit()
    End Sub

    Private Sub Main_Application_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim MyForm3 As New Form1

        MyForm3.ShowDialog()
    End Sub
End Class