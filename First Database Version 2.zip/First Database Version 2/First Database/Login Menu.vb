﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim MyForm4 As New Moderator
        Dim MyForm5 As New User
        Dim MyDatabaseGrid As New Database
        Dim LoopCount, RowCount, Level, DBLevel As Integer
        Dim UserName, Password, DBUserName, DBPassword As String
        Dim UserFound As Boolean

        MyDatabaseGrid.TBL_UserTableAdapter.Fill(MyDatabaseGrid.DSuser.TBL_User)

        UserName = txtUser.Text
        Password = txtPassword.Text
        RowCount = MyDatabaseGrid.DSuser.TBL_User.Rows.Count - 1
        LoopCount = 0
        UserFound = False
        Do While (LoopCount <= RowCount) And (UserFound = False)
            DBUserName = MyDatabaseGrid.DSuser.Tables("TBL User").Rows(LoopCount)(1).ToString()
            If UserName = DBUserName Then
                UserFound = True
            Else
                LoopCount = LoopCount + 1
            End If
        Loop

        If Not UserFound Then
            MessageBox.Show("User not found.")
        Else
            DBPassword = MyDatabaseGrid.DSuser.Tables("TBL User").Rows(LoopCount)(2).ToString()
            If Password <> DBPassword Then
                MessageBox.Show("Password doesn't match.")
            Else
                DBLevel = MyDatabaseGrid.DSuser.Tables("TBL User").Rows(LoopCount)(3).ToString()
                Level = DBLevel
                Select Case Level
                    Case 1
                        'MessageBox.Show("Admin")
                        MyDatabaseGrid.ShowDialog()
                    Case 2
                        'MessageBox.Show("Moderator")
                        MyForm4.ShowDialog()
                    Case 3
                        'MessageBox.Show("User")
                        MyForm5.ShowDialog()
                End Select
            End If
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub txtPassword_TextChanged(sender As Object, e As EventArgs) Handles txtPassword.TextChanged

    End Sub
End Class