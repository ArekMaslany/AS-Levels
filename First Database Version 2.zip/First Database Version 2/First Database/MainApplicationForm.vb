﻿Public Class MainApplicationForm
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Application.Exit()
    End Sub

    Private Sub Main_Application_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DSDB.TBL_User' table. You can move, or remove it, as needed.
        Me.TBL_UserTableAdapter.Fill(Me.DSDB.TBL_User)
        'TODO: This line of code loads data into the 'DSDB.TBL_Level' table. You can move, or remove it, as needed.
        Me.TBL_LevelTableAdapter.Fill(Me.DSDB.TBL_Level)
        'TODO: This line of code loads data into the 'DSDB.TBL_Session' table. You can move, or remove it, as needed.
        Me.TBL_SessionTableAdapter.Fill(Me.DSDB.TBL_Session)
        Login_Menu.ShowDialog()
    End Sub
End Class