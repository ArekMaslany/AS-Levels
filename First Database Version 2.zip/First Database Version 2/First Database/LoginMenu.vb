﻿Public Class Login_Menu
    Public DBUserName, DBPassword As String
    Public DBLocation As Integer

    Private Sub Login_Menu_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim LastRow, UserID, LoopCount, RowCount, Level, DBLevel As Integer
        Dim UserName, Password As String
        Dim UserFound As Boolean
        Dim StartTime, EndTime As DateTime
        Dim MyDate As DateTime

        MainApplicationForm.TBL_UserTableAdapter.Fill(MainApplicationForm.DSDB.TBL_User)

        UserName = txtUser.Text
        Password = txtPassword.Text
        RowCount = MainApplicationForm.DSDB.TBL_User.Rows.Count - 1
        LoopCount = 0
        UserFound = False
        Do While (LoopCount <= RowCount) And (UserFound = False)
            DBUserName = MainApplicationForm.DSDB.Tables("TBL User").Rows(LoopCount)(1).ToString()
            If UserName = DBUserName Then
                UserFound = True
            Else
                LoopCount = LoopCount + 1
            End If
        Loop
        DBLocation = LoopCount
        If Not UserFound Then
            MessageBox.Show("User not found.")
        Else
            DBPassword = MainApplicationForm.DSDB.Tables("TBL User").Rows(LoopCount)(2).ToString()
            If Password <> DBPassword Then
                MessageBox.Show("Incorrect Password.")
            Else
                DBLevel = MainApplicationForm.DSDB.Tables("TBL User").Rows(LoopCount)(3).ToString()
                Level = DBLevel
                StartTime = TimeOfDay
                MyDate = Today
                UserID = MainApplicationForm.DSDB.Tables("TBL User").Rows(LoopCount)(0)
                Select Case Level
                    Case 1
                        'MessageBox.Show("Admin")
                        Administrator.ShowDialog()
                    Case 2
                        'MessageBox.Show("Moderator")
                        Moderator.ShowDialog()
                    Case 3
                        'MessageBox.Show("User")
                        User.ShowDialog()
                End Select
                EndTime = TimeOfDay

                MainApplicationForm.DSDB.TBL_Session.Rows.Add()
                LastRow = MainApplicationForm.DSDB.TBL_Session.Rows.Count - 1
                MainApplicationForm.DSDB.Tables("TBL SESSION").Rows(LastRow)(2) = UserID
                MainApplicationForm.DSDB.Tables("TBL SESSION").Rows(LastRow)(3) = MyDate
                MainApplicationForm.DSDB.Tables("TBL SESSION").Rows(LastRow)(4) = StartTime
                MainApplicationForm.DSDB.Tables("TBL SESSION").Rows(LastRow)(5) = EndTime
                MainApplicationForm.TBL_SessionTableAdapter.Update(MainApplicationForm.DSDB.TBL_Session)
                MainApplicationForm.TBL_SessionTableAdapter.Fill(MainApplicationForm.DSDB.TBL_Session)
            End If
        End If
        txtUser.Text = ""
        txtPassword.Text = ""
    End Sub

End Class