﻿Public Class Database
    Private Sub Database_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DSuser.TBL_User' table. You can move, or remove it, as needed.
        Me.TBL_UserTableAdapter.Fill(Me.DSuser.TBL_User)

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        Me.TBL_UserTableAdapter.Update(Me.DSuser.TBL_User)
        Me.TBL_UserTableAdapter.Fill(Me.DSuser.TBL_User)
    End Sub

    Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs) Handles ToolStripButton2.Click
        Me.TBL_UserTableAdapter.Update(Me.DSuser.TBL_User)
        Me.TBL_UserTableAdapter.Fill(Me.DSuser.TBL_User)
    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged

    End Sub

    Private Sub BindingNavigator1_RefreshItems(sender As Object, e As EventArgs) Handles BindingNavigator1.RefreshItems

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnMoveFirst.Click
        TBLUserBindingSource.MoveFirst()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnMovePrevious.Click
        TBLUserBindingSource.MovePrevious()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles btnMoveNext.Click
        TBLUserBindingSource.MoveNext()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnMoveLast.Click
        TBLUserBindingSource.MoveLast()
    End Sub

    Private Sub BindingNavigatorDeleteItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorDeleteItem.Click

    End Sub

    Private Sub btnAddNewItem_Click(sender As Object, e As EventArgs) Handles btnAddNewItem.Click
        TBLUserBindingSource.AddNew()
    End Sub

    Private Sub btnDeleteNewItem_Click(sender As Object, e As EventArgs) Handles btnDeleteNewItem.Click
        TBLUserBindingSource.RemoveCurrent()
    End Sub

    Private Sub btnSaveEdit_Click(sender As Object, e As EventArgs) Handles btnSaveEdit.Click
        TBLUserBindingSource.EndEdit()
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles btn8.Click
        DSuser.Tables("TBL_User").Rows(TBLUserBindingSource.Position)(2) = TextBox2.Text
        Label10.Text = "Current record is: " & TBLUserBindingSource.Position + 1 & " of: " & TBLUserBindingSource.Count
    End Sub

    Private Sub TBLUserBindingSource_PositionChanged(sender As Object, e As EventArgs) Handles TBLUserBindingSource.PositionChanged
        Label10.Text = "Current record is: " & TBLUserBindingSource.Position + 1 & " of: " & TBLUserBindingSource.Count
    End Sub

    Private Sub TextBox9_TextChanged(sender As Object, e As EventArgs) Handles TextBox9.TextChanged

    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

    End Sub
End Class
