﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class User
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnChangePassForm = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnChangePassForm
        '
        Me.btnChangePassForm.Location = New System.Drawing.Point(12, 271)
        Me.btnChangePassForm.Name = "btnChangePassForm"
        Me.btnChangePassForm.Size = New System.Drawing.Size(197, 23)
        Me.btnChangePassForm.TabIndex = 33
        Me.btnChangePassForm.Text = "Another Change Password Button"
        Me.btnChangePassForm.UseVisualStyleBackColor = True
        '
        'User
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1428, 306)
        Me.Controls.Add(Me.btnChangePassForm)
        Me.Name = "User"
        Me.Text = "User"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnChangePassForm As Button
End Class
