﻿Public Class ChangePassword
    Private Sub ChangePassword_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Text = "Welcome " & Login_Menu.dbusername
        txtOld.Text = ""
        txtNew.Text = ""
        txtNew2.Text = ""

    End Sub

    Private Sub btnChangePass_Click(sender As Object, e As EventArgs) Handles btnChangePass.Click
        If txtOld.Text <> Login_Menu.DBPassword Then
            MsgBox("Incorrect Password.")
        Else
            If txtNew.Text <> txtNew2.Text Then
                MsgBox("New passwords dont match.")
            Else
                Administrator.DSuser.Tables("TBL User").Rows(Login_Menu.DBLocation)(2) = txtNew.Text
                Administrator.TBL_UserTableAdapter.Update(Administrator.DSuser.TBL_User)
                Administrator.TBL_UserTableAdapter.Fill(Administrator.DSuser.TBL_User)
                MsgBox("Password changed successfully.")
                Me.Close()
            End If
        End If
    End Sub
End Class