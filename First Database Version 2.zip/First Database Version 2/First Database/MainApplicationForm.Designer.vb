﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainApplicationForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.DSDB = New First_Database.DSDB()
        Me.DSDBBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TBLSessionBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TBL_SessionTableAdapter = New First_Database.DSDBTableAdapters.TBL_SessionTableAdapter()
        Me.TBLLevelBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TBL_LevelTableAdapter = New First_Database.DSDBTableAdapters.TBL_LevelTableAdapter()
        Me.TBLUserBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TBL_UserTableAdapter = New First_Database.DSDBTableAdapters.TBL_UserTableAdapter()
        CType(Me.DSDB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DSDBBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TBLSessionBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TBLLevelBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TBLUserBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 12)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 34)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Temporary Button"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'DSDB
        '
        Me.DSDB.DataSetName = "DSDB"
        Me.DSDB.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DSDBBindingSource
        '
        Me.DSDBBindingSource.DataSource = Me.DSDB
        Me.DSDBBindingSource.Position = 0
        '
        'TBLSessionBindingSource
        '
        Me.TBLSessionBindingSource.DataMember = "TBL Session"
        Me.TBLSessionBindingSource.DataSource = Me.DSDB
        '
        'TBL_SessionTableAdapter
        '
        Me.TBL_SessionTableAdapter.ClearBeforeFill = True
        '
        'TBLLevelBindingSource
        '
        Me.TBLLevelBindingSource.DataMember = "TBL Level"
        Me.TBLLevelBindingSource.DataSource = Me.DSDBBindingSource
        '
        'TBL_LevelTableAdapter
        '
        Me.TBL_LevelTableAdapter.ClearBeforeFill = True
        '
        'TBLUserBindingSource
        '
        Me.TBLUserBindingSource.DataMember = "TBL User"
        Me.TBLUserBindingSource.DataSource = Me.DSDB
        '
        'TBL_UserTableAdapter
        '
        Me.TBL_UserTableAdapter.ClearBeforeFill = True
        '
        'MainApplicationForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.ControlBox = False
        Me.Controls.Add(Me.Button1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "MainApplicationForm"
        Me.Text = "Main Application Form"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.DSDB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DSDBBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TBLSessionBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TBLLevelBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TBLUserBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents DSDB As DSDB
    Friend WithEvents DSDBBindingSource As BindingSource
    Friend WithEvents TBLSessionBindingSource As BindingSource
    Friend WithEvents TBL_SessionTableAdapter As DSDBTableAdapters.TBL_SessionTableAdapter
    Friend WithEvents TBLLevelBindingSource As BindingSource
    Friend WithEvents TBL_LevelTableAdapter As DSDBTableAdapters.TBL_LevelTableAdapter
    Friend WithEvents TBLUserBindingSource As BindingSource
    Friend WithEvents TBL_UserTableAdapter As DSDBTableAdapters.TBL_UserTableAdapter
End Class
