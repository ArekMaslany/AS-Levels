﻿Public Class Moderator
    Private Sub btnChangePassForm_Click(sender As Object, e As EventArgs) Handles btnChangePassForm.Click
        ChangePassword.Show()
    End Sub
End Class